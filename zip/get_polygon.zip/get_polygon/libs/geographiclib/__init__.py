"""geographiclib: geodesic routines from GeographicLib"""

__version_info__ = (2,
                    0,
                    0)
"""GeographicLib version as a tuple"""

__version__ = "2.0"
"""GeographicLib version as a string"""

__release_date__ = "2022-04-23"
"""GeographicLib release date"""
